var fs = require("fs");
var path = require("path");
var { createCanvas } = require("canvas");

let data = JSON.parse(fs.readFileSync(path.join(__dirname, "tmp", `${process.argv[2]}.json`)));
let canvas = createCanvas(data.width, data.height);
let ctx = canvas.getContext("2d");
let buffer = Buffer.from(data.data, "base64");
let offset = 0;
for (let y = 0; y < data.height; y++) {
    for (let x = 0; x < data.width; x++) {
        let r = ("0" + buffer.readUInt8(offset).toString(16)).slice(-2);
        let g = ("0" + buffer.readUInt8(offset + 1).toString(16)).slice(-2);
        let b = ("0" + buffer.readUInt8(offset + 2).toString(16)).slice(-2);
        let a = ("0" + buffer.readUInt8(offset + 3).toString(16)).slice(-2);
        offset += 4;
        ctx.fillStyle = "#" + r + g + b + a;
        ctx.fillRect(x, y, 1, 1);
    }
}
fs.writeFileSync(path.join(__dirname, "skins", `${process.argv[2]}.png`), canvas.toBuffer("image/png"));
fs.unlinkSync(path.join(__dirname, "tmp", `${process.argv[2]}.json`));